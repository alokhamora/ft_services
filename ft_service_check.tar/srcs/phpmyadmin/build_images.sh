docker build -t phpmyadmin_image .
