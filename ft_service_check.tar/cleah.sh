kubectl delete deployments --all
kubectl delete service nginx-svc
kubectl delete service wordpress-svc
kubectl delete service mysql-svc
kubectl delete service phpmyadmin-svc
kubectl delete service influxdb-svc
kubectl delete service grafana-svc
kubectl delete service ftps-svc
